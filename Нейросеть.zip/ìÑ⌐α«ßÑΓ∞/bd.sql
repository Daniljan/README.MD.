CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(100),
    role VARCHAR(50) DEFAULT 'user', -- Примеры: 'admin', 'technician', 'manager'
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE requests (
    id SERIAL PRIMARY KEY,
    request_number VARCHAR(50) NOT NULL,
    date_added TIMESTAMP NOT NULL DEFAULT NOW(),
    device_type VARCHAR(100),
    device_model VARCHAR(100),
    problem_desc TEXT,
    customer_name VARCHAR(150),
    phone_number VARCHAR(20),
    status VARCHAR(50) DEFAULT 'Новая заявка',
    user_id INT REFERENCES users(id)
);

-- Таблица: Комментарии
CREATE TABLE comments (
    id SERIAL PRIMARY KEY,
    request_id INT NOT NULL REFERENCES requests(id) ON DELETE CASCADE,
    user_id INT NOT NULL REFERENCES users(id),
    comment_text TEXT NOT NULL,
    date_added TIMESTAMP DEFAULT NOW()
);

-- Таблица: Комплектующие
CREATE TABLE parts (
    id SERIAL PRIMARY KEY,
    request_id INT NOT NULL REFERENCES requests(id) ON DELETE CASCADE,
    part_name VARCHAR(100),
    quantity INT DEFAULT 1,
    ordered_date TIMESTAMP DEFAULT NOW()
);

INSERT INTO users (username, password_hash, full_name, role) VALUES
('admin', '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92', 'Администратор', 'admin'),
('tech1', '5e884898da28047151d0e56f8dc6292773603d0d6aabbdd...', 'Иванов Иван', 'technician');

-- Добавим заявки
INSERT INTO requests (request_number, device_type, device_model, problem_desc, customer_name, phone_number, status, user_id)
VALUES
('REQ-001', 'Ноутбук', 'Lenovo ThinkPad X1', 'Не включается', 'Сидоров Сидор', '+79001112233', 'Новая заявка', 1),
('REQ-002', 'Принтер', 'HP LaserJet 1020', 'Мажет бумагу', 'Кузнецов Кузьма', '+79005556677', 'В процессе ремонта', 2);

-- Комментарии от техников
INSERT INTO comments (request_id, user_id, comment_text) VALUES
(1, 1, 'Диагностика показала проблему с материнской платой'),
(2, 2, 'Необходима замена роликов подачи бумаги');

-- Заказанные детали
INSERT INTO parts (request_id, part_name, quantity) VALUES
(1, 'Материнская плата Lenovo X1', 1),
(2, 'Ролик подачи бумаги HP 1020', 2);

SELECT setval('imported_requests_request_id_seq', 1, false);
/* Где 'imported_requests_request_id_seq' — это имя sequence, которое обычно PostgreSQL генерирует как:
<table_name>_<column_name>_seq */