﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class FormAdmin : Form
    {

        string connectionString = "Server=localhost;Port=5432;User Id=postgres;Password=123;Database=postgres;";

        public FormAdmin()
        {
            InitializeComponent();
            LoadRequests();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            using (var conn = new NpgsqlConnection(connectionString))
            {
                conn.Open();
                string query = @"INSERT INTO requests
        (request_number, device_type, device_model, problem_desc, customer_name, phone_number, status)
        VALUES (@num, @type, @model, @desc, @name, @phone, @status)";

                using (var cmd = new NpgsqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@num", txtRequestNumber.Text);
                    cmd.Parameters.AddWithValue("@type", txtDeviceType.Text);
                    cmd.Parameters.AddWithValue("@model", txtDeviceModel.Text);
                    cmd.Parameters.AddWithValue("@desc", txtProblemDesc.Text);
                    cmd.Parameters.AddWithValue("@name", label6.Text);
                    cmd.Parameters.AddWithValue("@phone", txtPhoneNumber.Text);
                    cmd.Parameters.AddWithValue("@status", cmbStatus.Text);

                    cmd.ExecuteNonQuery();
                }
            }

            LoadRequests();
            MessageBox.Show("Заявка добавлена.");
        }

        private void LoadRequests()
        {
            using (var conn = new NpgsqlConnection(connectionString))
            {
                conn.Open();
                string query = "SELECT * FROM requests ORDER BY date_added DESC";
                using (var da = new NpgsqlDataAdapter(query, conn))
                {
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dataGridView1.DataSource = dt;
                }
            }

            dataGridView1.Columns["id"].Visible = false;
        }

        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0) return;

            var row = dataGridView1.SelectedRows[0];
            txtRequestNumber.Text = row.Cells["request_number"].Value?.ToString();
            txtDeviceType.Text = row.Cells["device_type"].Value?.ToString();
            txtDeviceModel.Text = row.Cells["device_model"].Value?.ToString();
            txtProblemDesc.Text = row.Cells["problem_desc"].Value?.ToString();
            label6.Text = row.Cells["customer_name"].Value?.ToString();
            txtPhoneNumber.Text = row.Cells["phone_number"].Value?.ToString();
            cmbStatus.Text = row.Cells["status"].Value?.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0) return;

            int id = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["id"].Value);

            using (var conn = new NpgsqlConnection(connectionString))
            {
                conn.Open();
                string query = @"UPDATE requests SET
        request_number = @num, device_type = @type, device_model = @model,
        problem_desc = @desc, customer_name = @name, phone_number = @phone, status = @status
        WHERE id = @id";

                using (var cmd = new NpgsqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@id", id);
                    cmd.Parameters.AddWithValue("@num", txtRequestNumber.Text);
                    cmd.Parameters.AddWithValue("@type", txtDeviceType.Text);
                    cmd.Parameters.AddWithValue("@model", txtDeviceModel.Text);
                    cmd.Parameters.AddWithValue("@desc", txtProblemDesc.Text);
                    cmd.Parameters.AddWithValue("@name", label6.Text);
                    cmd.Parameters.AddWithValue("@phone", txtPhoneNumber.Text);
                    cmd.Parameters.AddWithValue("@status", cmbStatus.Text);

                    cmd.ExecuteNonQuery();
                }
            }

            LoadRequests();
            MessageBox.Show("Заявка обновлена.");
        }
    }
}
