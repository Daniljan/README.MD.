﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class FormMain : Form
    {
        string connectionString = "Server=localhost;Port=5432;User Id=postgres;Password=123;Database=postgres;";
        DataTable cart = new DataTable();
        private List<DataRow> basketRequests = new List<DataRow>();
        private ContextMenuStrip contextMenu;

        public FormMain()
        {
            InitializeComponent();
            LoadRequests();
            SetupContextMenu();
        }

        private void LoadRequests()
        {
            string query = @"
        SELECT r.id, r.request_number, r.date_added, r.device_type, r.device_model, 
               r.problem_desc, r.customer_name, r.phone_number, r.status,
               u.full_name AS technician
        FROM requests r
        LEFT JOIN users u ON r.user_id = u.id
        ORDER BY r.date_added DESC";

            using (var conn = new NpgsqlConnection(connectionString))
            {
                conn.Open();
                using (var cmd = new NpgsqlCommand(query, conn))
                {
                    using (var adapter = new NpgsqlDataAdapter(cmd))
                    {
                        DataTable table = new DataTable();
                        adapter.Fill(table);
                        dataGridView1.DataSource = table;
                    }
                }
            }

            // Настройка колонок (необязательно)
            dataGridView1.Columns["id"].Visible = false; // скрыть ID
            dataGridView1.AutoResizeColumns();
        }

        private void SetupContextMenu()
        {
            contextMenu = new ContextMenuStrip();
            var addToBasketItem = new ToolStripMenuItem("Добавить в корзину");
            addToBasketItem.Click += AddToBasket_Click;
            contextMenu.Items.Add(addToBasketItem);

            dataGridView1.ContextMenuStrip = contextMenu;
            dataGridView1.MouseDown += dataGridView1_MouseDown;
        }

        private void AddToBasket_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                var rowView = dataGridView1.SelectedRows[0].DataBoundItem as DataRowView;
                if (rowView != null && !basketRequests.Contains(rowView.Row))
                {
                    basketRequests.Add(rowView.Row);
                    MessageBox.Show("Заявка добавлена в корзину.");
                }
            }
        }

        private void dataGridView1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                var hit = dataGridView1.HitTest(e.X, e.Y);
                if (hit.RowIndex >= 0)
                {
                    dataGridView1.ClearSelection();
                    dataGridView1.Rows[hit.RowIndex].Selected = true;
                }
            }
        }

        private void btnAddToCart_Click(object sender, EventArgs e)
        {
            if (basketRequests.Count == 0)
            {
                MessageBox.Show("Корзина пуста.");
                return;
            }

            FormCart basketForm = new FormCart(basketRequests);
            basketForm.ShowDialog();
        }
    }
}