﻿using Npgsql;
using System.Data;

namespace WinFormsApp1
{
    public partial class FormCart : Form
    {
        string connectionString = "Server=localhost;Port=5432;User Id=postgres;Password=123;Database=postgres;";

        public FormCart(List<DataRow> selectedRequests)
        {
            InitializeComponent();

            DataTable basketTable = selectedRequests.Count > 0
            ? selectedRequests[0].Table.Clone() // структура таблицы
            : new DataTable();

            foreach (var row in selectedRequests)
            {
                basketTable.ImportRow(row);
            }

            dataGridView1.DataSource = basketTable;
            dataGridView1.AutoResizeColumns();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (dataGridView1.Rows.Count == 0)
            {
                MessageBox.Show("Корзина пуста.");
                return;
            }

            using (var conn = new NpgsqlConnection(connectionString))
            {
                conn.Open();

                using (var transaction = conn.BeginTransaction())
                {
                    try
                    {
                        foreach (DataGridViewRow row in dataGridView1.Rows)
                        {
                            if (row.IsNewRow) continue;

                            string partName = row.Cells["device_model"].Value?.ToString();
                            int quantity = Convert.ToInt32(textBox1.Text);
                            int requestId = Convert.ToInt32(row.Cells["id"].Value);

                            string insertQuery = @"INSERT INTO parts (request_id, part_name, quantity)
                                           VALUES (@requestId, @partName, @quantity)";

                            using (var cmd = new NpgsqlCommand(insertQuery, conn))
                            {
                                cmd.Parameters.AddWithValue("@requestId", requestId);
                                cmd.Parameters.AddWithValue("@partName", partName);
                                cmd.Parameters.AddWithValue("@quantity", quantity);
                                cmd.ExecuteNonQuery();
                            }
                        }

                        transaction.Commit();
                        MessageBox.Show("Заказ оформлен успешно!");
                        dataGridView1.Rows.Clear();
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        MessageBox.Show("Ошибка при оформлении заказа: " + ex.Message);
                    }
                }
            }
        }
    }
}