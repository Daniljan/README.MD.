﻿using Npgsql;

namespace WinFormsApp1
{
    public partial class FormLogin : Form
    {
        string connectionString = "Server=localhost;Port=5432;User Id=postgres;Password=123;Database=postgres;";

        public FormLogin()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string login = txtUsername.Text.Trim();
            string password = txtPassword.Text;

            using (var conn = new NpgsqlConnection(connectionString))
            {
                conn.Open();

                string query = "SELECT * FROM users WHERE username = @username AND password_hash = @password";
                using (var cmd = new NpgsqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@username", login);
                    cmd.Parameters.AddWithValue("@password", password);

                    using (var reader = cmd.ExecuteReader())
                    {
                        if (reader.HasRows)
                        {
                            reader.Read();

                            string role = reader["role"].ToString();
                            string fullName = reader["full_name"].ToString();

                            MessageBox.Show($"Добро пожаловать, {fullName} ({role})!");

                   
                            switch (role)
                            {
                                case "user":
                                    new FormMain().Show();
                                    break;
                                case "admin":
                                    new FormAdmin().Show();
                                    break;
                                case "manager":
                                    break;
                                default:
                                    MessageBox.Show("Неизвестная роль. Обратитесь к администратору.");
                                    return;
                            }

                            this.Hide(); 
                        }
                        else
                        {
                            MessageBox.Show("Неверный логин или пароль");
                        }
                    }
                }
            }
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            FormRegister register = new FormRegister();
            register.Show();
            this.Hide();
        }
    }
}